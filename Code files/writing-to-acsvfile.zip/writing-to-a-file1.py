##########################################
# Writing to a file1
# Shiva K
##########################################

fileName = "Hello1.txt"
accessMode = 'w'
myFile = open(fileName,accessMode)

myFile.write("Hi,")
myFile.write("How are you?")
myFile.close()

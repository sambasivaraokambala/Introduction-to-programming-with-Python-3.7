##########################################
# Writing to a csv file1
# Shiva K
##########################################
fileName = "Shiva.csv"
accessMode = "w"


name = input("Enter your name:")
age = input("Enter you age:")

file = open(fileName,accessMode)
file.write(name + "," + age )
file.close()

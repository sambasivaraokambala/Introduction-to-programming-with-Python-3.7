##############################################
# loops-changing the color of a pen
# Shiva K
##############################################

import turtle

for steps in range(4):
    turtle.forward(100)
    turtle.right(90)
turtle.color('red')
turtle.forward(200)

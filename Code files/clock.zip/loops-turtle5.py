################################################
# Loops- turtle5
# Shiva K
################################################

#import turtle module
import turtle

objectSides = input("Enter number of sides:")
numberOfSides = int(objectSides)

# Repeat the loop  for 5 times
for steps in range(numberOfSides):
    turtle.forward(100)
    turtle.right(360/numberOfSides)
# Repeat the loop for 5 times
    for stepes in range(numberOfSides):
        turtle.forward(50)
        turtle.right(360/numberOfSides)

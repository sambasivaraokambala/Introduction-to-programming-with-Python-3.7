################################################
# Loops- turtle3
# Shiva K
################################################

#import turtle module
import turtle


# Repeat the loop  for 5 times
for steps in range(5):
    turtle.forward(100)
    turtle.right(360/5)
# Repeat the loop for 5 times
    for stepes in range(5):
        turtle.forward(50)
        turtle.right(360/5)

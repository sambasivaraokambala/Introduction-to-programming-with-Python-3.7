##############################################
# Loops-turtle2
# Shiva.Kambala
##############################################

import turtle

# Cursor picks the color 'Green'
turtle.color('Green')

# Draws the line(green) 100 units forward(Cursor starts its position at (0,0)
turtle.forward(100)

# Cursor changes its direction in 45 degrees right
turtle.right(45)

# Cursor picks(changes to) the 'blue' color
turtle.color('blue')

# Draws a line forward for 50 units
turtle.forward(50)

# Takes 45 degree right from its current direction
turtle.right(45)

# picks the 'pink' color'
turtle.color('pink')

# moves forward 100 units
turtle.forward(100)

########################################
# Loopinside another loop
# Shiva K
########################################

import turtle

for steps in range(4):
    turtle.forward(100)
    turtle.right(90)
    for steps in range(4):
        turtle.forward(50)
        turtle.right(90)

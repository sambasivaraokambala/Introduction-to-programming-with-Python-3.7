################################################
# Loops- listofdifferent types
# Shiva K
################################################
import turtle

for steps in ['Pavan','Deepanshu','Sai','Nagesh',10,13,24.5]:
    print(steps)

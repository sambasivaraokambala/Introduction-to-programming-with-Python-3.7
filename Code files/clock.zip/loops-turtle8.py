################################################
# Loops- index
# Shiva K
################################################

# We can specify the number to skip in between two numbers
for steps in range(1,16,3):
    print(steps)

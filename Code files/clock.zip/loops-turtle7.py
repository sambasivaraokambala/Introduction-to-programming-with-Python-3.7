################################################
# Loops- index
# Shiva K
################################################

# We can specify the number from which that count should start
for steps in range(1,6):
    print(steps)

################################################
# Loops- listcolors
# Shiva K
################################################
import turtle

# no drawing takes place
turtle.penup()

# Move pen to 300 left to origin a
turtle.setx(-300)

# Move pen to 250 upper to origin
turtle.sety(250)
turtle.down()
# We can specify the number to skip in between two numbers
for steps in ['red','green','blue','yellow']:
    turtle.color(steps)
    turtle.forward(100)
    turtle.right(90)

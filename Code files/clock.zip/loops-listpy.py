################################################
# Loops- print list of values
# Shiva K
################################################

# We can specify the number to skip in between two numbers
for steps in [1,16,3,14,17.20]:
    print(steps)

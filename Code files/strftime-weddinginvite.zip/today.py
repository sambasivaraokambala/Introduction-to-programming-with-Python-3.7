###############################################
# Displaying today's date
# Shiva K
###############################################

# import statement gives access to the class 'datetime' which contains
# the function today
import datetime


# print today's date

print(datetime.date.today())
 

###########################################
# Asking for user inpput
# Shiva kambala
###########################################

# Asking for user name
name = input("Your name?")

# printing name
print(name)


# Changes the name to "Mahesh"
name = "Mahesh"

# Prints the changed value of the variable 'name'
print("\nAfter Change")
print(name)

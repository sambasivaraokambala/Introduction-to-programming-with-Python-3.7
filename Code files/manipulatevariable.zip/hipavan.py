a = "hello"
b = " Pavan"

print(a b);

###########################################
# Asking for user inpput
# Shiva kambala
###########################################

# Asking for user name
name = input("Your name?")

# printing name
print(name)

#########################################################
# Printing multiple lines
# Shiva K
#########################################################

print('''Hickory Dickory dock
The mouse ran up the clock\n''')


print("""Hickory Dickory dock
The mouse ran up the clock""")

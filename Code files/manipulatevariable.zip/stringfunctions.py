############################################
# Variable manipulation
# Shiva Kambala
############################################


# Taking userinput
animal = input("Your favourite animal:")


# Converts the user input to lower case
print(animal.lower())

# Converts the user input to upper case
print(animal.upper())

# Converts the upper case letter to smaller case and smaller case to upper
print(animal.swapcase())



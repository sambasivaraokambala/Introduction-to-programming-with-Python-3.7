# My first python application
# Shiva Kambala
# print function prints a message on the screen.

print("hello,World!")

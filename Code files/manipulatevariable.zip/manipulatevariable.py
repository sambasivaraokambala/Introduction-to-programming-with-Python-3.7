############################################
# Storytelling Program
# Shiva Kambala
############################################


# Taking userinput
animal = input(“Your favourite animal:”)
building = input(“Name a famous building:”)
color = input(“Your favourite colour:”)

# Telling the story

print("Hickory Dickory Dock!“)
print("The "+color+" "+animal+" ran up the "+building)



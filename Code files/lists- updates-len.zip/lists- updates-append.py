#############################################
# Updating lists using append
# Shiva K
#############################################

guests = ["Sachin Tendulkar","Sourav Ganguly","Yuvraj Singh","M.S.Dhoni","Zaheer Khan",
          "Anil Kumble"]


for guest in guests:
    print(guest)

# append updates a new value at the end of the list

guests.append("Gautam Gambhir")
print("-------------------------")

for guest in guests:
    print(guest)




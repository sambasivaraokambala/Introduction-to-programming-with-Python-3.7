#############################################
# Displaying values using for loop
# Shiva K
#############################################

employees = ["Czeck","Ramesey","Ozil","Xzaka"]

for steps in range(4):
    print(employees[steps])




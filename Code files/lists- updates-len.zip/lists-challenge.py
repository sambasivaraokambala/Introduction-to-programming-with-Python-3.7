################################################
# Lists - Challenge
# Shiva K
################################################
guests= []
name = " "

while name.upper() != "DONE":
    name = input("Enter username(When you are finished,plz type 'Done')")
    guests.append(name)

guests.sort()
for guest in guests:
    print(guest)
    

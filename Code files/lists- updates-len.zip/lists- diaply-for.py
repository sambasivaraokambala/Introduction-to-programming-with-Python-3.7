#############################################
# Displaying values using simple for loop
# Shiva K
#############################################

employees = ["Czeck","Ramesey","Ozil","Xzaka"]

for employee in employees:
    print(employee)



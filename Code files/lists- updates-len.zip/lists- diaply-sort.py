#############################################
# Displaying sorted values
# Shiva K
#############################################



myFbFrnds = ['Steve','Ramsey','Ozil','Xzaka']

# sorts the list in Alphabetical order
myFbFrnds.sort()

for frnd in myFbFrnds:
	print(frnd)




#############################################
# Index function
# Shiva K
#############################################

guests = ["Sachin Tendulkar","Sourav Ganguly","Yuvraj Singh","M.S.Dhoni","Zaheer Khan",
          "Anil Kumble"]



print(guests.index("Sourav Ganguly"))




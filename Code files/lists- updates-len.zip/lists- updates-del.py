#############################################
# del command
# Shiva K
#############################################

guests = ["Sachin Tendulkar","Sourav Ganguly","Yuvraj Singh","M.S.Dhoni","Zaheer Khan",
          "Anil Kumble"]


for guest in guests:
    print(guest)


# delete the 4th guest name from the list

del guests[3]
print("-------------------------")

for guest in guests:
    print(guest)




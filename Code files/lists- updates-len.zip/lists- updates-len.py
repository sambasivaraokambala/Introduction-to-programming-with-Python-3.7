#############################################
# Displaying values using len function
# Shiva K
#############################################

employees = ["Czeck","Ramesey","Ozil","Xzaka"]

numberOfEmployees = len(employees)

for steps in range(numberOfEmployees):
    print(employees[steps])



#############################################
# Updating lists
# Shiva K
#############################################

guests = ["Sachin Tendulkar","Sourav Ganguly","Yuvraj Singh","M.S.Dhoni","Zaheer Khan",
          "Anil Kumble"]


# prints the first guest

print(guests[0])

guests[0] = "Gautam Gambhir"

# prints the updated value

print(guests[0])

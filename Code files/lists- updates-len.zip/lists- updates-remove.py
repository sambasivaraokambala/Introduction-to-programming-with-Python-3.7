#############################################
# Removing a value from the list using remove function
# Shiva K
#############################################

guests = ["Sachin Tendulkar","Sourav Ganguly","Yuvraj Singh","M.S.Dhoni","Zaheer Khan",
          "Anil Kumble"]


for guest in guests:
    print(guest)

# append updates a new value at the end of the list

guests.remove("Sachin Tendulkar")
print("-------------------------")

for guest in guests:
    print(guest)




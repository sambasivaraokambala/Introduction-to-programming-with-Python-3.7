########################################
# While loop5
# Shiva K
########################################

import turtle

count = 1
# It creates an endless loop
while count < 4 :
    turtle.forward(100)
    turtle.right(90)
    

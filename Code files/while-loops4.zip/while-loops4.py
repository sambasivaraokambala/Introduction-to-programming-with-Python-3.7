########################################
# While loop4
# Shiva K
########################################

import turtle

count = 1
# It draws 5 lines
while count < 4 :
    turtle.forward(100)
    turtle.right(90)
    

########################################
# While loop1
# Shiva K
########################################

answer = "0"

while answer != "4":
    answer = input("What is 2 + 2 ?")

print("yes, 2+2 is four")

########################################
# While loop2
# Shiva K
########################################

import turtle

count = 0
while count < 4 :
    turtle.forward(100)
    turtle.right(90)
    count = count + 1

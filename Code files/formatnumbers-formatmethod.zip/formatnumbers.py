############################################
# Format Numbers
# Shiva K
############################################

print("I have %d cats" %6)
print("I have %3d cats" %6)
print("I have %03d cats" %6)
print("I have %f cats" %6)
print('I have %.2f cats'  %6)



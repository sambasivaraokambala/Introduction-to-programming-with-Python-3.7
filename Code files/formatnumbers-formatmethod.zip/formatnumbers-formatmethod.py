###############################################
# Format numbers using format method
# Shiva K
###############################################

print("I have {0:d} cats".format(6))
print("I have {0:3d} cats".format(6))
print("I have {0:03d} cats".format(6))
print("I have {0:f} cats".format(6))
print("I have {0:.2f} cats".format(6))

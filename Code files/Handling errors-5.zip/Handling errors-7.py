########################################
# Handling errors-7
# Shiva k
########################################
import sys

# Takes user two numbers from user
numerator = input("Enter a numerator:")
denominator = input("Enter denominator:")
# Division
try:
    result = float(numerator) / float(denominator)
    # Printing the result
    print("The result is :" + str(result))
except:
    print("I am sorry,something went wrong!")
    sys.exit()
print("This message only executes,if there is no error.")

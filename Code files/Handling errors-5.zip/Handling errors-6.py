########################################
# Handling errors-6
# Shiva k
########################################
import sys

# Takes user two numbers from user
numerator = input("Enter a numerator:")
denominator = input("Enter denominator:")

# Division
try:
    result = float(numerator) / float(denominator)
    # Printing the result
    print("The result is :" + str(result))
except ZeroDivisionError:
    print("The answer is infinity")
except:
    error = sys.exc_info()[0]
    print("I am sorry,something went wrong!")
    print(error)
print("This code always executes.")

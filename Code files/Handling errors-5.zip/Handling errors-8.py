##################################################
# Handling errors-8
# Shiva K
##################################################

firstNumber = input("Enter your first number:")
secondNumber = input("Enter your second number:)
result = float(firstNumber) / float(secondNumber)
print(result)
    

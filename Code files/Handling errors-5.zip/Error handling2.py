##############################################
# Error Handling -Typing Error
# Shiva K
##############################################

prnit("Hello,world")

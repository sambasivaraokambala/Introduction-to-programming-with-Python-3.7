##############################################
# Error Handling - Logical Error1
# Shiva K
##############################################


salary = '50000'
bonus = '10000'

payCheck = salary + bonus
print(payCheck)

########################################
# Handling errors-Calcualtor
# Shiva k
########################################

# Takes user two numbers from user
numerator = input("Enter a numerator:")
denominator = input("Enter denominator:")

# Division
try:
    result = float(numerator) / float(denominator)
    # Printing the result
    print("The result is :" + str(result))
except:
    print("Something went wrong!")

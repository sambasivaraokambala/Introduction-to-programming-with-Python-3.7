########################################
# Handling errors-exc_info()
# Shiva k
########################################
import sys

# Takes user two numbers from user
numerator = input("Enter a numerator:")
denominator = input("Enter denominator:")

# Division
try:
    result = float(numerator) / float(denominator)
    # Printing the result
    print("The result is :" + str(result))
except:
    error = sys.exc_info()[0]
    print("Something went wrong!")
    print(error)

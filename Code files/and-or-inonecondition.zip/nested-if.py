###################################################
# nested - if statements
# Shiva K
###################################################

monDay = True
freshCoffee = False
if monDay:
    if not freshCoffee:
        print("Go and buy a fresh coffee!")
    print("I hate Monday")
print("You can go to office now!")

############################################
# decision making using and
# Shiva K
############################################

bigWin = True
WonLottery = True

if WonLottery and bigWin:
    print("Retire for life")

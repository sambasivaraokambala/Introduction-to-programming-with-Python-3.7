##########################################
# Decision making - or
# Shiva K
##########################################


# There are two variables namely Saturday and Sunday
saturDay = False

sunDay = True

if saturDay or sunDay:
    print("You can sleep in")
    

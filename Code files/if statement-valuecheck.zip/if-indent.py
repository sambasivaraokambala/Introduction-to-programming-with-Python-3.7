##################################################
# Syntax of an if statement
# Shiva k
##################################################

answer = input("would you like express shipping(Yes/no)?")

if answer == "Yes" or answer == "Y" or answer == "y":
    print("That will be of extra 10$.")
print("Thanks for your time!")

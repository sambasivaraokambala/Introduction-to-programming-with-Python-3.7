########################################
# If statement checking boundary conditions
# Shiva K
########################################

deposit = input("What is the deposit amount?")

if int(deposit) > 100:
    print("You get a free toast!")
print("Have a nice day!")

#################################################
# if-statement user input example
# Shiva K
#################################################

deposit = input("Enter deposit amount:")

if deposit > 100:
    print("You will get a free toast!")
print("Thanks")

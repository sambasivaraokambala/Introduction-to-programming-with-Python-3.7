############################################
# An example program for if-else
# Shiva K
############################################

deposit = input("Enter deposit amount:")

if float(deposit) > 100 :
    print("You will receive a free toaster")
else :
    print("Enjoy a free mug")
    
print("Thanks")

###############################################
# corrected the code crash
# Shiva k
###############################################


deposit = int(input("Enter deposit amount:"))
# #####one more way ############################
# deposit = input("Enter the deposit amount:") 
# if int(deposit) > 100:
################################################
if deposit > 100:
    print("You will receive a free toast!")

print("Thanks!")

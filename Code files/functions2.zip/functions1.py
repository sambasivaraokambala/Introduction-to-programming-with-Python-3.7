##################################################
# functions1
# Shiva K
##################################################


# Create a function that prints "Hello,World!"
def printMessage():
    print("Hello,World!")
    return

# Calling the function to print "Hello World!"
printMessage()
printMessage()

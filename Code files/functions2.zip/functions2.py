##################################################
# functions1
# Shiva K
##################################################


# Create a function that prints custome message
def printMessage(message):
    print(message)
    return

# Calling the function to print the message that
# we pass in as parameter.
printMessage("Shiva")
printMessage(" teaches Python.")
printMessage("He knows Tableua as well.")
